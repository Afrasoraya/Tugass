package Tugas2;

public class MyClassPrime implements Runnable {
	@Override
	public void run() {
		System.out.println("Silahkan Menunggu 1 menit untuk hasil 10 Bilangan Prima Pertama");
		try {
			Thread.sleep(60000);
			int n = 30;
	        System.out.println("10 Bilangan Prima Pertama adalah : ");
	        for(int i=2; i<n; i++) {
	            boolean isPrima = true;
	            
	            for (int j = 2; j < i; j++) {
	                if(i%j==0){
	                    isPrima = false;
	                    break;
	                    
	                    
	                }
	            }
	            if(isPrima==true){
	                System.out.print(i+",");
	            }
	        }
	        System.out.println(" ");
	        System.out.println(" ");
	        System.out.println("Silahkan Menunggu 1 menit untuk hasil 20 Bilangan Fibonacci Pertama");
		} catch (InterruptedException e) {

		}
	}
}
