//[SI-MENE] MOOP MINGGU DELAPAN
//AFRA SORAYA - 2001600393

package Tugas2;

public class Demo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClassPrime prime = new MyClassPrime();
		Thread thread = new Thread(prime);
		thread.start();
		
		MyClassFibonacci2 fibonacci2= new MyClassFibonacci2();
		Thread thread2 = new Thread(fibonacci2);
		thread2.start();
		
	}

}
