package Tugas1;

public class MyClassFibonacci1 implements Runnable {
	int angka;

	public MyClassFibonacci1(int angka) {
		this.angka = angka;
	}

	@Override
	public void run() {
		int n = 20, angka1 = 0, angka2 = 1;
		System.out.println(n + "Bilangan Fibonacci: ");

		
		for (int i = 1; i <= n; ++i) {
			System.out.print(angka1 + " ");
			int sum = angka1 + angka2;
			angka1 = angka2;
			angka2 = sum;

			if (sum != angka1 + angka2 && angka1 != angka2 && angka2 != sum) {
				System.out.println("Bukan Bilangan Fibonacci");
			} else {
				System.out.println("Termasuk Bilangan Fibonacci");
			}
		}
	}

}
