package Tugas1;

public class MyClassGanjilGenap1 implements Runnable{
int angka1;
	
	public MyClassGanjilGenap1(int angka) {
		System.out.println("Silahkan menunggu 30 detik untuk hasil bilangan genap dan ganjil");
		this.angka1 = angka1;
	}


	@Override
	public void run() {
		try {
			Thread.sleep(30000);
			if(angka1 %2 == 1){
				System.out.println("Termasuk Bilangan Ganjil");
			}
			else{
				System.out.println("Termasuk Bilangan Genap");
			}
		} catch (InterruptedException e) {
		}
	}
}
