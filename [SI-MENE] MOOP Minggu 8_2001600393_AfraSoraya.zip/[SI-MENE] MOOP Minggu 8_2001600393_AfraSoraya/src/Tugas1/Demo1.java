//[SI-MENE] MOOP MINGGU DELAPAN
//AFRA SORAYA - 2001600393
package Tugas1;

import java.util.Scanner;


public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		int angka;
		
		System.out.println("Silahkan Masukan Angka : ");
		angka = scan.nextInt();scan.nextLine();
		MyClassGanjilGenap1 ganjilgenap = new MyClassGanjilGenap1(angka);
		Thread thread = new Thread(ganjilgenap);
		thread.start();

		MyClassFibonacci1 fibonacci = new MyClassFibonacci1(angka);
		Thread thread2 = new Thread(fibonacci);
		thread2.start();
	}

}
